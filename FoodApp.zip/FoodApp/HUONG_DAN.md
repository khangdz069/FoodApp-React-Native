# FoodApp — Đề kiểm tra Nhóm 3

Expo SDK 57 · TypeScript · Redux Toolkit · React Navigation · AsyncStorage (không dùng redux-persist).

## Chạy

Mở 2 terminal trong thư mục `FoodApp`:

```bash
npm run server      # json-server: http://localhost:3000/foods
npx expo start      # quét QR bằng Expo Go, hoặc bấm a (Android) / w (web)
```

**BASE_URL** nằm ở `src/config.ts`:
- Android Emulator: tự dùng `http://10.0.2.2:3000`
- Web / iOS Simulator: `http://localhost:3000`
- Điện thoại thật (Expo Go cùng Wi‑Fi): điền `LAN_URL = 'http://<IP máy>:3000'` (xem IP bằng `ipconfig`)

## Đổi đề (chỉ khác dữ liệu JSON)

1. Dán JSON của đề vào `server/db.json`.
2. Nếu tên resource khác `foods` / `coupons` → sửa `FOODS_PATH`, `COUPONS_PATH` trong `src/config.ts`.
3. Nếu trường của món khác → sửa kiểu `Food` trong `src/types.ts` (và chỗ hiển thị tên/ảnh trong `FoodCard`, `FoodDetailScreen`, `CartItemRow`).

> Đề Nhóm 3 bị cắt dữ liệu (chỉ có 2 món). `server/db.json` đã bổ sung món và mã giảm giá sao cho khớp đúng bảng kiểm tra: Pizza phô mai 129.000 đ, Gà rán giòn cay 69.000 đ, FOOD10 / GIAM50K / BIG20 / HET30.

## Vị trí từng câu

| Câu | File |
|---|---|
| 1 Cấu trúc | `App.tsx`, `src/store/index.ts`, `src/types.ts`, `src/navigation/*` |
| 2 Thực đơn | `src/screens/MenuScreen.tsx`, `src/components/FoodCard.tsx`, `FoodGrid.tsx`, `src/screens/FoodDetailScreen.tsx` |
| 3 Giỏ hàng | `src/store/cartSlice.ts`, `src/screens/CartScreen.tsx`, `src/components/CartItemRow.tsx`, badge ở `AppNavigator.tsx` |
| 4 AsyncStorage | `src/hooks/usePersist.ts` (một hook chung, khoá `@food/cart`, `@food/favorites`) |
| 5 Yêu thích | `src/store/favoritesSlice.ts`, `src/components/FavoriteButton.tsx`, `src/screens/FavoritesScreen.tsx`, `AccountScreen.tsx` |
| 6 Debounce | `src/hooks/useDebouncedQuantities.ts` (350ms; console in log `dispatch cart/setQuantity` để chụp minh chứng) |
| 7 Mã giảm giá | `src/utils/coupon.ts`, phần chân trang `CartScreen.tsx` |

Nộp bài: nén thư mục **bỏ `node_modules`** thành `MSSV_HoTen_FoodApp.zip`.
