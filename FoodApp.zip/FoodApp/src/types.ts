// Khớp các trường trong server/db.json
export type Food = {
  id: string;
  name: string;
  category: string;
  price: number;
  stock: number;
  rating: number;
  image: string;
  description: string;
};

export type CartItem = { food: Food; quantity: number };

export type Coupon = {
  id: string;
  code: string;
  type: 'percent' | 'fixed';
  value: number;
  minOrder: number;
  maxDiscount?: number;
  active: boolean;
};
