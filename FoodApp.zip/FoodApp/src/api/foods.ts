import { BASE_URL, COUPONS_PATH, FOODS_PATH } from '../config';
import type { Coupon, Food } from '../types';

async function request<T>(path: string): Promise<T> {
  const res = await fetch(`${BASE_URL}${path}`);
  if (!res.ok) throw new Error(`Lỗi ${res.status} khi gọi ${path}`);
  return res.json() as Promise<T>;
}

export const fetchFoods = () => request<Food[]>(FOODS_PATH);
export const fetchFoodById = (id: string) => request<Food>(`${FOODS_PATH}/${encodeURIComponent(id)}`);
export const fetchCouponsByCode = (code: string) =>
  request<Coupon[]>(`${COUPONS_PATH}?code=${encodeURIComponent(code)}`);
