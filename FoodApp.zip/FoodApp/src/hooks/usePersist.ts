import { useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { PayloadAction } from '@reduxjs/toolkit';
import { STORAGE_KEYS } from '../config';
import { useAppDispatch, useAppSelector, type RootState } from '../store';
import { hydrateCart } from '../store/cartSlice';
import { hydrateFavorites } from '../store/favoritesSlice';
import type { CartItem, Food } from '../types';

// dùng chung cho cart và favorites
export function usePersist<T>(options: {
  key: string;
  selectItems: (s: RootState) => T[];
  selectHydrated: (s: RootState) => boolean;
  hydrate: (items: T[]) => PayloadAction<T[]>;
  isValid: (x: unknown) => x is T;
}) {
  const { key, selectItems, selectHydrated, hydrate, isValid } = options;
  const dispatch = useAppDispatch();
  const items = useAppSelector(selectItems);
  const hydrated = useAppSelector(selectHydrated);

  // đọc dữ liệu khi mở app
  useEffect(() => {
    let cancelled = false;
    (async () => {
      let restored: T[] = [];
      try {
        const raw = await AsyncStorage.getItem(key);
        const parsed: unknown = raw ? JSON.parse(raw) : [];
        if (Array.isArray(parsed)) restored = parsed.filter(isValid);
      } catch (e) {
        console.warn(`Không đọc được ${key}`, e);
      }
      if (!cancelled) dispatch(hydrate(restored));
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);

  // ghi lại khi items đổi (chỉ sau khi đã đọc xong)
  useEffect(() => {
    if (!hydrated) return;
    AsyncStorage.setItem(key, JSON.stringify(items)).catch(e => console.warn(e));
  }, [key, items, hydrated]);

  return hydrated;
}

const isFood = (x: unknown): x is Food => {
  const f = x as Food;
  return !!f && typeof f.id === 'string' && typeof f.name === 'string' &&
    typeof f.price === 'number' && typeof f.stock === 'number';
};

const isCartItem = (x: unknown): x is CartItem => {
  const c = x as CartItem;
  return !!c && isFood(c.food) && typeof c.quantity === 'number' && c.quantity >= 1;
};

export function useAppPersistence() {
  const cartReady = usePersist<CartItem>({
    key: STORAGE_KEYS.cart,
    selectItems: s => s.cart.items,
    selectHydrated: s => s.cart.hydrated,
    hydrate: hydrateCart,
    isValid: isCartItem,
  });
  const favoritesReady = usePersist<Food>({
    key: STORAGE_KEYS.favorites,
    selectItems: s => s.favorites.items,
    selectHydrated: s => s.favorites.hydrated,
    hydrate: hydrateFavorites,
    isValid: isFood,
  });
  return cartReady && favoritesReady;
}
