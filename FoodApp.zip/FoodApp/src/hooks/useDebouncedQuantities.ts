import { useCallback, useEffect, useRef, useState } from 'react';
import { DEBOUNCE_MS } from '../config';
import { useAppDispatch } from '../store';
import { setQuantity } from '../store/cartSlice';

// giữ số lượng tạm, sau delay ms mới dispatch
export function useDebouncedQuantities(delay = DEBOUNCE_MS) {
  const dispatch = useAppDispatch();
  const [drafts, setDrafts] = useState<Record<string, number>>({});
  const timers = useRef<Record<string, ReturnType<typeof setTimeout>>>({});
  const pending = useRef<Record<string, number>>({});

  const dropDraft = (id: string) =>
    setDrafts(d => {
      const { [id]: _, ...rest } = d;
      return rest;
    });

  const commit = useCallback((id: string) => {
    const qty = pending.current[id];
    if (qty === undefined) return;
    dispatch(setQuantity({ id, quantity: qty }));
    delete pending.current[id];
    delete timers.current[id];
    dropDraft(id);
  }, [dispatch]);

  const changeQuantity = useCallback((id: string, qty: number) => {
    pending.current[id] = qty;
    setDrafts(d => ({ ...d, [id]: qty }));
    clearTimeout(timers.current[id]);
    timers.current[id] = setTimeout(() => commit(id), delay);
  }, [commit, delay]);

  // xoá món thì huỷ hẹn giờ của món đó
  const discard = useCallback((id: string) => {
    clearTimeout(timers.current[id]);
    delete timers.current[id];
    delete pending.current[id];
    dropDraft(id);
  }, []);

  const discardAll = useCallback(() => {
    Object.values(timers.current).forEach(clearTimeout);
    timers.current = {};
    pending.current = {};
    setDrafts({});
  }, []);

  // rời màn hình thì ghi các thay đổi còn chờ
  const flush = useCallback(() => {
    Object.values(timers.current).forEach(clearTimeout);
    Object.entries(pending.current).forEach(([id, quantity]) =>
      dispatch(setQuantity({ id, quantity })),
    );
    timers.current = {};
    pending.current = {};
    setDrafts({});
  }, [dispatch]);

  useEffect(() => () => {
    Object.values(timers.current).forEach(clearTimeout);
    Object.entries(pending.current).forEach(([id, quantity]) =>
      dispatch(setQuantity({ id, quantity })),
    );
  }, [dispatch]);

  return { drafts, changeQuantity, discard, discardAll, flush };
}
