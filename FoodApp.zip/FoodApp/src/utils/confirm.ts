import { Alert, Platform } from 'react-native';

// Alert xác nhận (trên web Alert không có nút nên dùng window.confirm)
export function confirmAction(title: string, message: string, okText: string, onConfirm: () => void) {
  if (Platform.OS === 'web') {
    if (window.confirm(`${title}\n${message}`)) onConfirm();
    return;
  }
  Alert.alert(title, message, [
    { text: 'Huỷ', style: 'cancel' },
    { text: okText, style: 'destructive', onPress: onConfirm },
  ]);
}
