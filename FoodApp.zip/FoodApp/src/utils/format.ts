// 59000 -> "59.000 đ"
export const formatVND = (n: number) =>
  `${Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.')} đ`;

// 9 -> "9.0"
export const formatRating = (n: number) => n.toFixed(1);
