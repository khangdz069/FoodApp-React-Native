import type { Coupon } from '../types';

// percent = min(tạm tính × value / 100, maxDiscount); fixed = min(value, tạm tính)
// Dưới minOrder thì giảm 0
export function calcDiscount(coupon: Coupon | null, subtotal: number): number {
  if (!coupon || subtotal < coupon.minOrder) return 0;
  if (coupon.type === 'percent') {
    const raw = Math.round((subtotal * coupon.value) / 100);
    return coupon.maxDiscount != null ? Math.min(raw, coupon.maxDiscount) : raw;
  }
  return Math.min(coupon.value, subtotal);
}
