import { useCallback, useEffect, useState } from 'react';
import { ActivityIndicator, Button, Text, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { fetchFoods } from '../api/foods';
import FoodGrid from '../components/FoodGrid';
import { RootStackParamList } from '../navigation/types';
import { Food } from '../types';

export default function MenuScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const [foods, setFoods] = useState<Food[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const load = async () => {
    try {
      setError('');
      const data = await fetchFoods();
      setFoods(data);
    } catch (e) {
      setError((e as Error).message);
    }
  };

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, []);

  const onRetry = () => {
    setLoading(true);
    load().finally(() => setLoading(false));
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await load();
    setRefreshing(false);
  };

  const openDetail = useCallback((id: string) => {
    navigation.navigate('FoodDetail', { foodId: id });
  }, [navigation]);

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center' }}>
        <ActivityIndicator size="large" />
      </View>
    );
  }

  if (error) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
        <Text style={{ color: 'red', marginBottom: 10 }}>Lỗi: {error}</Text>
        <Button title="Thử lại" onPress={onRetry} />
      </View>
    );
  }

  return <FoodGrid foods={foods} onPressFood={openDetail} refreshing={refreshing} onRefresh={onRefresh} />;
}
