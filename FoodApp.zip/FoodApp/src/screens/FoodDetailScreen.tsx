import { useEffect, useState } from 'react';
import { ActivityIndicator, Button, Image, ScrollView, StyleSheet, Text, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { fetchFoodById } from '../api/foods';
import FavoriteButton from '../components/FavoriteButton';
import { RootStackParamList } from '../navigation/types';
import { useAppDispatch, useAppSelector } from '../store';
import { addToCart, selectQuantityInCart } from '../store/cartSlice';
import { Food } from '../types';
import { formatVND } from '../utils/format';

type Props = NativeStackScreenProps<RootStackParamList, 'FoodDetail'>;

export default function FoodDetailScreen({ route }: Props) {
  const { foodId } = route.params;
  const dispatch = useAppDispatch();
  const inCart = useAppSelector(selectQuantityInCart(foodId));
  const [food, setFood] = useState<Food | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = () => {
    setLoading(true);
    setError('');
    fetchFoodById(foodId)
      .then(setFood)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    load();
  }, [foodId]);

  if (loading) {
    return <ActivityIndicator size="large" style={{ flex: 1 }} />;
  }

  if (error || !food) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ color: 'red', marginBottom: 10 }}>Lỗi: {error}</Text>
        <Button title="Thử lại" onPress={load} />
      </View>
    );
  }

  let buttonTitle = 'Thêm vào giỏ';
  if (food.stock === 0) buttonTitle = 'Hết hàng';
  else if (inCart >= food.stock) buttonTitle = `Đã đủ tồn kho (${food.stock})`;

  return (
    <ScrollView style={{ backgroundColor: 'white' }}>
      <View>
        <Image source={{ uri: food.image }} style={styles.image} />
        <FavoriteButton food={food} size={24} />
      </View>
      <View style={{ padding: 15 }}>
        <Text style={styles.name}>{food.name}</Text>
        <Text>Loại: {food.category}</Text>
        <Text style={styles.price}>{formatVND(food.price)}</Text>
        <Text>Tồn kho: {food.stock}</Text>
        <Text style={{ marginVertical: 10 }}>{food.description}</Text>
        <Button
          title={buttonTitle}
          color="tomato"
          disabled={food.stock === 0 || inCart >= food.stock}
          onPress={() => dispatch(addToCart(food))}
        />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  image: {
    width: '100%',
    aspectRatio: 1,
  },
  name: {
    fontSize: 22,
    fontWeight: 'bold',
  },
  price: {
    fontSize: 18,
    color: 'tomato',
    marginVertical: 5,
  },
});
