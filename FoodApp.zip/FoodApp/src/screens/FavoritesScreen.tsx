import { Button, Text, View } from 'react-native';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import FoodGrid from '../components/FoodGrid';
import { RootStackParamList } from '../navigation/types';
import { useAppSelector } from '../store';
import { selectFavorites } from '../store/favoritesSlice';

type Props = NativeStackScreenProps<RootStackParamList, 'Favorites'>;

export default function FavoritesScreen({ navigation }: Props) {
  const favorites = useAppSelector(selectFavorites);

  const emptyView = (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <Text style={{ fontSize: 16, marginBottom: 5 }}>Chưa có món yêu thích</Text>
      <Text style={{ color: 'gray', marginBottom: 15 }}>Bấm vào ♡ trên món ăn để thêm vào đây</Text>
      <Button title="Xem thực đơn" onPress={() => navigation.navigate('Tabs', { screen: 'Menu' })} />
    </View>
  );

  return (
    <FoodGrid
      foods={favorites}
      onPressFood={id => navigation.navigate('FoodDetail', { foodId: id })}
      ListEmptyComponent={emptyView}
    />
  );
}
