import { Text, TouchableOpacity, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { NativeStackNavigationProp } from '@react-navigation/native-stack';
import { RootStackParamList } from '../navigation/types';
import { useAppSelector } from '../store';
import { selectFavorites } from '../store/favoritesSlice';

export default function AccountScreen() {
  const navigation = useNavigation<NativeStackNavigationProp<RootStackParamList>>();
  const favorites = useAppSelector(selectFavorites);

  return (
    <View style={{ padding: 15 }}>
      <TouchableOpacity
        style={{ backgroundColor: 'white', padding: 15, borderRadius: 8, flexDirection: 'row', justifyContent: 'space-between' }}
        onPress={() => navigation.navigate('Favorites')}
      >
        <Text>♥ Món yêu thích</Text>
        <Text>{favorites.length} ›</Text>
      </TouchableOpacity>
    </View>
  );
}
