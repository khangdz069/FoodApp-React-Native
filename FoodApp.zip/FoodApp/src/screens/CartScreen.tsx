import { useCallback, useEffect, useMemo, useState } from 'react';
import { ActivityIndicator, Button, FlatList, StyleSheet, Text, TextInput, TouchableOpacity, View } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { fetchCouponsByCode } from '../api/foods';
import CartItemRow from '../components/CartItemRow';
import { useDebouncedQuantities } from '../hooks/useDebouncedQuantities';
import { useAppDispatch, useAppSelector } from '../store';
import { clearCart, removeFromCart, selectCartItems } from '../store/cartSlice';
import { CartItem, Coupon } from '../types';
import { confirmAction } from '../utils/confirm';
import { calcDiscount } from '../utils/coupon';
import { formatVND } from '../utils/format';

export default function CartScreen() {
  const dispatch = useAppDispatch();
  const navigation = useNavigation();
  const items = useAppSelector(selectCartItems);
  const { drafts, changeQuantity, discard, discardAll, flush } = useDebouncedQuantities();

  const [code, setCode] = useState('');
  const [coupon, setCoupon] = useState<Coupon | null>(null);
  const [checking, setChecking] = useState(false);
  const [message, setMessage] = useState('');

  // chuyển tab thì ghi luôn số lượng đang chờ
  useEffect(() => navigation.addListener('blur', flush), [navigation, flush]);

  const getQty = useCallback((item: CartItem) => drafts[item.food.id] ?? item.quantity, [drafts]);

  const subtotal = useMemo(
    () => items.reduce((sum, item) => sum + item.food.price * getQty(item), 0),
    [items, getQty],
  );
  const discount = calcDiscount(coupon, subtotal);
  const total = subtotal - discount;

  const applyCoupon = async () => {
    const c = code.trim().toUpperCase();
    if (!c) return;
    setChecking(true);
    setMessage('');
    try {
      const list = await fetchCouponsByCode(c);
      const found = list.find(x => x.code.toUpperCase() === c);
      if (!found) {
        setCoupon(null);
        setMessage('Mã không tồn tại');
      } else if (!found.active) {
        setCoupon(null);
        setMessage('Mã hết hiệu lực');
      } else {
        setCoupon(found);
        setCode(found.code);
      }
    } catch (e) {
      setMessage('Lỗi: ' + (e as Error).message);
    }
    setChecking(false);
  };

  const removeCoupon = () => {
    setCoupon(null);
    setCode('');
    setMessage('');
  };

  const onRemove = useCallback((item: CartItem) => {
    confirmAction('Xoá món', `Xoá "${item.food.name}" khỏi giỏ hàng?`, 'Xoá', () => {
      discard(item.food.id);
      dispatch(removeFromCart(item.food.id));
    });
  }, [dispatch, discard]);

  const onClear = () => {
    confirmAction('Xoá tất cả', 'Bạn có chắc muốn xoá hết giỏ hàng?', 'Xoá', () => {
      discardAll();
      dispatch(clearCart());
    });
  };

  if (items.length === 0) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ fontSize: 16 }}>Giỏ hàng trống</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1 }}>
      <FlatList
        data={items}
        keyExtractor={item => item.food.id}
        contentContainerStyle={{ padding: 10 }}
        ListHeaderComponent={
          <TouchableOpacity onPress={onClear} style={{ alignSelf: 'flex-end', marginBottom: 8 }}>
            <Text style={{ color: 'red' }}>Xoá tất cả</Text>
          </TouchableOpacity>
        }
        renderItem={({ item }) => (
          <CartItemRow item={item} quantity={getQty(item)} onChangeQuantity={changeQuantity} onRemove={onRemove} />
        )}
      />

      <View style={styles.footer}>
        <View style={styles.couponRow}>
          <TextInput
            style={styles.input}
            placeholder="Mã giảm giá"
            value={code}
            onChangeText={setCode}
            autoCapitalize="characters"
          />
          {checking ? <ActivityIndicator /> : <Button title="Áp dụng" color="tomato" onPress={applyCoupon} />}
        </View>

        {message !== '' && <Text style={{ color: 'red' }}>{message}</Text>}

        {coupon && (
          <View style={styles.couponRow}>
            <Text style={{ flex: 1, color: 'green' }}>Đã áp dụng mã {coupon.code}</Text>
            <TouchableOpacity onPress={removeCoupon}>
              <Text style={{ color: 'red' }}>Bỏ mã</Text>
            </TouchableOpacity>
          </View>
        )}
        {coupon && subtotal < coupon.minOrder && (
          <Text style={{ color: 'orange' }}>Còn thiếu {formatVND(coupon.minOrder - subtotal)} để dùng mã này</Text>
        )}

        <View style={styles.line}>
          <Text>Tạm tính</Text>
          <Text>{formatVND(subtotal)}</Text>
        </View>
        <View style={styles.line}>
          <Text>Giảm giá</Text>
          <Text>{formatVND(discount)}</Text>
        </View>
        <View style={styles.line}>
          <Text style={styles.total}>Tổng cộng</Text>
          <Text style={styles.total}>{formatVND(total)}</Text>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  footer: {
    backgroundColor: 'white',
    padding: 10,
    borderTopWidth: 1,
    borderColor: '#ddd',
  },
  couponRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  input: {
    flex: 1,
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 8,
    marginRight: 8,
  },
  line: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  total: {
    fontWeight: 'bold',
    fontSize: 16,
  },
});
