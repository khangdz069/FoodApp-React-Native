import { Platform } from 'react-native';

// Đổi IP này khi chạy trên điện thoại thật (xem bằng ipconfig), ví dụ 'http://192.168.1.10:3000'
const LAN_URL = '';

export const BASE_URL =
  LAN_URL || (Platform.OS === 'android' ? 'http://10.0.2.2:3000' : 'http://localhost:3000');

// Tên resource trong server/db.json — đề khác thì chỉ cần đổi ở đây
export const FOODS_PATH = '/foods';
export const COUPONS_PATH = '/coupons';

export const STORAGE_KEYS = {
  cart: '@food/cart',
  favorites: '@food/favorites',
};

export const DEBOUNCE_MS = 350;
