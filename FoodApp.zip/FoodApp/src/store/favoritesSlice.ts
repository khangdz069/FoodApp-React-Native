import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import type { Food } from '../types';
import type { RootState } from './index';

type FavoritesState = { items: Food[]; hydrated: boolean };
const initialState: FavoritesState = { items: [], hydrated: false };

const favoritesSlice = createSlice({
  name: 'favorites',
  initialState,
  reducers: {
    toggleFavorite(state, action: PayloadAction<Food>) {
      const idx = state.items.findIndex(f => f.id === action.payload.id);
      if (idx >= 0) state.items.splice(idx, 1);
      else state.items.push(action.payload);
    },
    hydrateFavorites(state, action: PayloadAction<Food[]>) {
      state.items = action.payload;
      state.hydrated = true;
    },
  },
});

export const { toggleFavorite, hydrateFavorites } = favoritesSlice.actions;
export default favoritesSlice.reducer;

export const selectFavorites = (s: RootState) => s.favorites.items;
export const selectIsFavorite = (id: string) => (s: RootState) =>
  s.favorites.items.some(f => f.id === id);
