import { configureStore, Middleware } from '@reduxjs/toolkit';
import { TypedUseSelectorHook, useDispatch, useSelector } from 'react-redux';
import cartReducer, { setQuantity } from './cartSlice';
import favoritesReducer from './favoritesSlice';

// log để kiểm tra debounce
const logSetQuantity: Middleware = () => next => action => {
  if (setQuantity.match(action)) {
    console.log(`[${new Date().toLocaleTimeString()}] dispatch ${action.type}`, action.payload);
  }
  return next(action);
};

export const store = configureStore({
  reducer: { cart: cartReducer, favorites: favoritesReducer },
  middleware: getDefault => getDefault().concat(logSetQuantity),
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
export const useAppDispatch: () => AppDispatch = useDispatch;
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;
