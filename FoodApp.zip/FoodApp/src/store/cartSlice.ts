import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import type { CartItem, Food } from '../types';
import type { RootState } from './index';

type CartState = { items: CartItem[]; hydrated: boolean };
const initialState: CartState = { items: [], hydrated: false };

// Số lượng luôn nằm trong [1, stock]
const clamp = (qty: number, stock: number) => Math.max(1, Math.min(Math.floor(qty), stock));

const cartSlice = createSlice({
  name: 'cart',
  initialState,
  reducers: {
    addToCart(state, action: PayloadAction<Food>) {
      const food = action.payload;
      if (food.stock <= 0) return;
      const item = state.items.find(i => i.food.id === food.id);
      if (item) {
        item.food = food; // cập nhật tồn kho mới nhất
        item.quantity = clamp(item.quantity + 1, food.stock);
      } else {
        state.items.push({ food, quantity: 1 });
      }
    },
    setQuantity(state, action: PayloadAction<{ id: string; quantity: number }>) {
      const item = state.items.find(i => i.food.id === action.payload.id);
      if (item) item.quantity = clamp(action.payload.quantity, item.food.stock);
    },
    removeFromCart(state, action: PayloadAction<string>) {
      state.items = state.items.filter(i => i.food.id !== action.payload);
    },
    clearCart(state) {
      state.items = [];
    },
    hydrateCart(state, action: PayloadAction<CartItem[]>) {
      state.items = action.payload;
      state.hydrated = true;
    },
  },
});

export const { addToCart, setQuantity, removeFromCart, clearCart, hydrateCart } = cartSlice.actions;
export default cartSlice.reducer;

export const selectCartItems = (s: RootState) => s.cart.items;
// Badge = tổng số phần (không phải số dòng)
export const selectCartCount = (s: RootState) => s.cart.items.reduce((n, i) => n + i.quantity, 0);
export const selectQuantityInCart = (id: string) => (s: RootState) =>
  s.cart.items.find(i => i.food.id === id)?.quantity ?? 0;
