import React from 'react';
import { Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { Food } from '../types';
import { formatRating, formatVND } from '../utils/format';
import FavoriteButton from './FavoriteButton';

type Props = {
  food: Food;
  onPress: (id: string) => void;
};

function FoodCard({ food, onPress }: Props) {
  return (
    <TouchableOpacity style={styles.card} onPress={() => onPress(food.id)}>
      <View>
        <Image source={{ uri: food.image }} style={styles.image} />
        <FavoriteButton food={food} />
        {food.stock === 0 && <Text style={styles.soldOut}>Tạm hết</Text>}
      </View>
      <Text style={styles.name} numberOfLines={1}>{food.name}</Text>
      <Text style={styles.price}>{formatVND(food.price)}</Text>
      <Text>⭐ {formatRating(food.rating)}</Text>
    </TouchableOpacity>
  );
}

export default React.memo(FoodCard);

const styles = StyleSheet.create({
  card: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 8,
  },
  image: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: 6,
  },
  soldOut: {
    position: 'absolute',
    left: 6,
    bottom: 6,
    backgroundColor: 'gray',
    color: 'white',
    paddingHorizontal: 6,
    paddingVertical: 2,
    fontSize: 12,
  },
  name: {
    marginTop: 6,
    fontWeight: 'bold',
  },
  price: {
    color: 'tomato',
  },
});
