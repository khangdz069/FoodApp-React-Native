import React from 'react';
import { Button, Image, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { CartItem } from '../types';
import { formatVND } from '../utils/format';

type Props = {
  item: CartItem;
  quantity: number;
  onChangeQuantity: (id: string, quantity: number) => void;
  onRemove: (item: CartItem) => void;
};

function CartItemRow({ item, quantity, onChangeQuantity, onRemove }: Props) {
  const { food } = item;

  return (
    <View style={styles.row}>
      <Image source={{ uri: food.image }} style={styles.image} />
      <View style={{ flex: 1 }}>
        <Text style={styles.name}>{food.name}</Text>
        <Text>{formatVND(food.price)}</Text>
        <View style={styles.qtyRow}>
          <Button title=" − " disabled={quantity <= 1} onPress={() => onChangeQuantity(food.id, quantity - 1)} />
          <Text style={styles.qty}>{quantity}</Text>
          <Button title=" + " disabled={quantity >= food.stock} onPress={() => onChangeQuantity(food.id, quantity + 1)} />
        </View>
        <Text>Thành tiền: {formatVND(food.price * quantity)}</Text>
      </View>
      <TouchableOpacity onPress={() => onRemove(item)}>
        <Text style={styles.remove}>Xoá</Text>
      </TouchableOpacity>
    </View>
  );
}

export default React.memo(CartItemRow);

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    backgroundColor: 'white',
    padding: 10,
    marginBottom: 10,
    borderRadius: 8,
  },
  image: {
    width: 70,
    height: 70,
    marginRight: 10,
  },
  name: {
    fontWeight: 'bold',
  },
  qtyRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 5,
  },
  qty: {
    marginHorizontal: 12,
    fontSize: 16,
  },
  remove: {
    color: 'red',
  },
});
