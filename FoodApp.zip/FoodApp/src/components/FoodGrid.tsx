import React from 'react';
import { FlatList, useWindowDimensions, View } from 'react-native';
import { Food } from '../types';
import FoodCard from './FoodCard';

type Props = {
  foods: Food[];
  onPressFood: (id: string) => void;
  ListEmptyComponent?: React.ReactElement;
  refreshing?: boolean;
  onRefresh?: () => void;
};

export default function FoodGrid({ foods, onPressFood, ListEmptyComponent, refreshing, onRefresh }: Props) {
  const { width } = useWindowDimensions();
  const itemWidth = (width - 30) / 2; // padding 10 x 2 + gap 10

  return (
    <FlatList
      data={foods}
      keyExtractor={item => item.id}
      numColumns={2}
      renderItem={({ item }) => (
        <View style={{ width: itemWidth }}>
          <FoodCard food={item} onPress={onPressFood} />
        </View>
      )}
      columnWrapperStyle={{ gap: 10 }}
      contentContainerStyle={[{ padding: 10, gap: 10 }, foods.length === 0 && { flexGrow: 1 }]}
      ListEmptyComponent={ListEmptyComponent}
      refreshing={refreshing}
      onRefresh={onRefresh}
    />
  );
}
