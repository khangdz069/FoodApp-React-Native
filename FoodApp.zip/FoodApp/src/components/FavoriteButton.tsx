import { Pressable, StyleProp, StyleSheet, Text, ViewStyle } from 'react-native';
import { useAppDispatch, useAppSelector } from '../store';
import { selectIsFavorite, toggleFavorite } from '../store/favoritesSlice';
import { Food } from '../types';

type Props = {
  food: Food;
  size?: number;
  style?: StyleProp<ViewStyle>;
};

export default function FavoriteButton({ food, size = 18, style }: Props) {
  const dispatch = useAppDispatch();
  const isFav = useAppSelector(selectIsFavorite(food.id));

  return (
    <Pressable style={[styles.btn, style]} onPress={() => dispatch(toggleFavorite(food))}>
      <Text style={{ fontSize: size, color: isFav ? 'red' : 'black' }}>{isFav ? '♥' : '♡'}</Text>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  btn: {
    position: 'absolute',
    top: 6,
    right: 6,
    backgroundColor: 'white',
    borderRadius: 20,
    paddingHorizontal: 7,
    paddingVertical: 2,
  },
});
