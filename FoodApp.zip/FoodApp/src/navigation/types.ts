import type { NavigatorScreenParams } from '@react-navigation/native';

export type TabParamList = { Menu: undefined; Cart: undefined; Account: undefined };

export type RootStackParamList = {
  Tabs: NavigatorScreenParams<TabParamList>;
  FoodDetail: { foodId: string };
  Favorites: undefined;
};
